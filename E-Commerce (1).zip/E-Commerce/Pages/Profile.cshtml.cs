﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace E_Commerce.Pages
{
	public class ProfileModel : PageModel
    {
        [BindProperty]
        [Required]
        [MinLength(9, ErrorMessage = "Enter a valid Email")]
        [MaxLength(50, ErrorMessage = " Enter a valid Email")]
        public string? Email { get; set; }

        [BindProperty]
        [Required]
        [MaxLength(11, ErrorMessage = "Enter a valid number with max 11 nums")]
        [MinLength(11, ErrorMessage = "Enter a valid number with min 11 nums")]
        public string? Phone { get; set; }

        [BindProperty]
        public string? OldPassword { get; set; }

        [BindProperty]
        public string? NewPassword { get; set; }

        public void OnGet()
        {

        }
        public IActionResult OnPost()
        {
            if (ModelState.IsValid)
            {
                return RedirectToPage("/Account");
            }
            return Page();
        }
    }
}
