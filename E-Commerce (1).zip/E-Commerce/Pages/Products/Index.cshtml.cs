using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace WebApplication4.Pages.Clients
{
    public class IndexModel : PageModel
    {
        public List<ClientInfo>listClients = new List<ClientInfo>();
        public void OnGet()
        {
            try
            {
                string connectionString = "Data Source=DESKTOP-0LGVPP6;Initial Catalog=HarryPotter;Integrated Security=True";
                using(SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string sql = "SELECT * FROM Products";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using(SqlDataReader reader = command.ExecuteReader())
                        {
                            while(reader.Read())
                            {
                                ClientInfo clientInfo = new ClientInfo();
								clientInfo.id = "" + reader.GetString(0);
								clientInfo.name = "" + reader.GetString(1);
								clientInfo.ProductDiscription = "" + reader.GetString(2);
								clientInfo.ProductCategory = "" + reader.GetString(3);
								clientInfo.Price = 0 + reader.GetInt32(4);
								clientInfo.created_at = "" + reader.GetDateTime(5).ToString();
                                listClients.Add(clientInfo);
							}
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.ToString());
            }
        }
        public class ClientInfo
        {
            public string id;
            public string name;
            public string ProductDiscription;
            public string ProductCategory;
            public int Price;
            public string created_at;
        }
    }
}
