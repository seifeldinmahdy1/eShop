﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace E_Commerce.Pages;

public class HomeModel : PageModel
{
    private readonly ILogger<HomeModel> _logger;

    public HomeModel(ILogger<HomeModel> logger)
    {
        _logger = logger;
    }

    public void OnGet()
    {

    }
    public IActionResult OnPostFruits()
    {
        return RedirectToPage("/Fruits");
    }
    public IActionResult OnPostBakery()
    {
        return RedirectToPage("/Bakery");
    }
    public IActionResult OnPostSeaFood()
    {
        return RedirectToPage("/Seafood");
    }
    public IActionResult OnPostMedication()
    {
        return RedirectToPage("/Medication");
    }
    public IActionResult OnPostButchery()
    {
        return RedirectToPage("/Butchery");
    }
    public IActionResult OnPostBeverages()
    {
        return RedirectToPage("/Beverages");
    }
    public IActionResult OnPostDairy()
    {
        return RedirectToPage("/Dairy");
    }
    public IActionResult OnPostPets()
    {
        return RedirectToPage("/Pets");
    }

}

