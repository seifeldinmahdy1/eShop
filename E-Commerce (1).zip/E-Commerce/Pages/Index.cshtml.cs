﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace E_Commerce.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }

        public void OnGet()
        {

        }
        public IActionResult OnPostSignUp()
        {
            // Add your sign-in logic here if needed

            // Redirect to the Index page
            return RedirectToPage("/RegisterationForm");
        }
        public IActionResult OnPostSignIn()
        {
            // Add your sign-in logic here if needed

            // Redirect to the Index page
            return RedirectToPage("/Home");
        }
    }
}