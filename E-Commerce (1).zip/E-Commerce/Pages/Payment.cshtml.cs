﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace E_Commerce.Pages
{
	public class PaymentModel : PageModel
    {
        [BindProperty]
        [Required]
        [MinLength(11, ErrorMessage = "Enter a valid credit card number")]
        [MaxLength(17, ErrorMessage = " Enter a valid credit card number")]
        public string? Number { get; set; }

        [BindProperty]
        [Required]
        [MaxLength(2, ErrorMessage = "Enter a valid cvv")]
        [MinLength(4, ErrorMessage = "Enter a valid cvv")]
        public string? cvv { get; set; }

        [BindProperty]
        public string? Date { get; set; }

        public void OnGet()
        {

        }
        public IActionResult OnPost()
        {
            if (ModelState.IsValid)
            {
                return RedirectToPage("/Account");
            }
            return Page();
        }
    }
}
