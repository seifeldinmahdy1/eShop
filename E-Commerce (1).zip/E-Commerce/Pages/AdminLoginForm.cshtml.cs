using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace E_Commerce.Pages
{
    public class AdminLoginFormModel : PageModel
    {
        public void OnGet()
        {
        }
        public IActionResult OnPostSignIn()
        {
            return RedirectToPage("/Products/Index");
        }
    }
}
