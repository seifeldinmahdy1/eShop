using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace E_Commerce.Pages
{
    public class RegisterationFormModel : PageModel
    {
        public void OnGet()
        {
        }
        public IActionResult OnPostSignIn()
        {
            // Add your sign-in logic here if needed

            // Redirect to the Index page
            return RedirectToPage("/Index");
        }
    }
}
