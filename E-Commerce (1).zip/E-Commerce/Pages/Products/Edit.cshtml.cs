using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace WebApplication4.Pages.Clients
{
	public class EditModel : PageModel
	{
		public Clients.IndexModel.ClientInfo clientInfo = new Clients.IndexModel.ClientInfo();
		public string errorMessege = "";
		public string successMessege = "";
		private SqlDataReader reader;

		public void OnGet()
		{
			string id = Request.Query["id"];
			try
			{
				string connectionString = "Data Source=DESKTOP-0LGVPP6;Initial Catalog=HarryPotter;Integrated Security=True";
				using (SqlConnection connection = new SqlConnection(connectionString))
				{
					connection.Open();
					string sql = "SELECT * FROM Products WHERE id=@id";
					using (SqlCommand command = new SqlCommand(sql, connection))
					{
						command.Parameters.AddWithValue("@id", id);
						reader = command.ExecuteReader();
						while (reader.Read())
						{
							clientInfo.id = "" + reader.GetString(0);
							clientInfo.name = "" + reader.GetString(1);
							clientInfo.ProductDiscription = "" + reader.GetString(2);
							clientInfo.ProductCategory = "" + reader.GetString(3);
							clientInfo.Price = 0 + reader.GetInt32(4);
						}
					}
				}
			}
			catch (Exception ex)
			{
				errorMessege = ex.Message;
			}
		}

		public void OnPost()
		{
			clientInfo.name = Request.Form["name"];
			clientInfo.id = Request.Form["id"];
			clientInfo.ProductDiscription = Request.Form["email"];
			clientInfo.ProductCategory = Request.Form["phone"];

			clientInfo.Price = reader.GetInt32(4);

			if (clientInfo.name.Length == 0 || clientInfo.ProductDiscription.Length == 0 ||
				clientInfo.ProductCategory.Length == 0 || clientInfo.Price == 0)
			{
				errorMessege = "All The Fields Are Required";
				return;
			}

			try
			{
				string connectionString = "Data Source=DESKTOP-0LGVPP6;Initial Catalog=HarryPotter;Integrated Security=True";
				using (SqlConnection sqlConnection = new SqlConnection(connectionString))
				{
					sqlConnection.Open();
					string sql = "UPDATE Products " + "SET name=@name, ProductDiscription=@ProductDiscription, ProductCategory=@ProductCategory, Price=@Price " +
						"WHERE id= @id";
					using (SqlCommand command = new SqlCommand(sql, sqlConnection))
					{
						command.Parameters.AddWithValue("@name", clientInfo.name);
						command.Parameters.AddWithValue("@id", clientInfo.id);
						command.Parameters.AddWithValue("@ProductDiscription", clientInfo.ProductDiscription);
						command.Parameters.AddWithValue("@ProductCategory", clientInfo.ProductCategory);
						command.Parameters.AddWithValue("@Price", clientInfo.Price);
						command.ExecuteNonQuery();
					}
				}
			}
			catch (Exception ex)
			{
				errorMessege = ex.Message;
				return;
			}

			Response.Redirect("/Products/Index");
		}
	}
}